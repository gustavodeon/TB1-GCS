# TB1 | Gerenciamento de Configuração de Software 2022

Esse é o repositório do grupo criativamente chamado de 'Grupo 2', aqui fica o código bem como link para outras ferramentas utilizadas para o desenvolvimento do trabalho.

## Links Externos

[**Board**](https://trello.com/b/VvIU7MiD/trabalho-gcs)

[**Relatório**](TBD)

## Membros do Grupo

- [Gustavo Vicentini Deon](https://www.github.com/Def4uIt)
- 
